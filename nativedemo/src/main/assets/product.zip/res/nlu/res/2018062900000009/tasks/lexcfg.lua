local name = "nlucore";
local lexdb = {};

lexdb.use_trie = 1;
lexdb.data = {};
lexdb.pwd = "${pwd}";
lexdb.ext_path = lexdb.pwd .. "/../vocabs";

lexdb.data["sys.技能操作词"] = lexdb.pwd .. "/../vocabs/sys.技能操作词.bin";
lexdb.data["list"] = lexdb.pwd .. "/../vocabs/list.bin";
lexdb.data["sys.技能调用名"] = lexdb.pwd .. "/../vocabs/sys.技能调用名.bin";
lexdb.data["action"] = lexdb.pwd .. "/../vocabs/action.bin";
lexdb.data["change"] = lexdb.pwd .. "/../vocabs/change.bin";
lexdb.data["seach"] = lexdb.pwd .. "/../vocabs/seach.bin";
lexdb.data["wind"] = lexdb.pwd .. "/../vocabs/wind.bin";
lexdb.data["mode"] = lexdb.pwd .. "/../vocabs/mode.bin";
lexdb.data["temperature"] = lexdb.pwd .. "/../vocabs/temperature.bin";
lexdb.data["help"] = lexdb.pwd .. "/../vocabs/help.bin";
lexdb.data["rest"] = lexdb.pwd .. "/../vocabs/rest.bin";
return lexdb;
