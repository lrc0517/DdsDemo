local M = {}

function M:reform_cb_entry( domain, output ) 
    --output格式与merge或reform是否打开有关,如果都打开了则为定义的输出格式
    return output
end

function M:music_crf_merge_slots(lex_result, result)
    local is_found
    local engine = "crf"
    --print("music crf merge slots")
    for i=1, table.maxn(result[engine]) do
        for k,v in pairs(result[engine][i]) do
            is_found = false
            for i1=1, table.maxn(lex_result.tokens) do
                for k1,v1 in pairs(lex_result.tokens[i1]) do
                    if( k1 == k ) then
                        is_found = true
                        if type(v[1])=="string" and type(v1[1])=="string" then
                            if string.len(v[1]) > string.len(v1[1]) then
                                lex_result.tokens[i1][k1] = v
                            else
                                if string.len(v[1]) == string.len(v1[1]) then
                                    if v1[1] < v[1] then                                    
                                        lex_result.tokens[i1][k1] = v
                                    end
                                end
                            end
                        end
                    end
                end
            end
            if not is_found then
                local tmp = {}
                tmp[k] = v
                table.insert(lex_result.tokens,tmp)
            end
        end
    end
end

return M
