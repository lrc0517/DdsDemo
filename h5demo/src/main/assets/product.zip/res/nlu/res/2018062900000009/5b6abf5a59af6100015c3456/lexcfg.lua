local name = "nlucore";
local lexdb = {};

lexdb.use_trie = 1;
lexdb.data = {};
lexdb.pwd = "${pwd}";
lexdb.ext_path = lexdb.pwd .. "/../vocabs";

lexdb.data["wind"] = lexdb.pwd .. "/../vocabs/wind.bin";
lexdb.data["mode"] = lexdb.pwd .. "/../vocabs/mode.bin";
lexdb.data["temperature"] = lexdb.pwd .. "/../vocabs/temperature.bin";
return lexdb;
